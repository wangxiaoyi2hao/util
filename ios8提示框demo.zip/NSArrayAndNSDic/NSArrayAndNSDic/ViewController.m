//
//  ViewController.m
//  NSArrayAndNSDic
//
//  Created by 安永超 on 15/11/25.
//  Copyright © 2015年 安永超. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *array=@[@"章撒",@"俩都",@"啊覅有",@"还u",@"萨芬哈哈"];
    NSDictionary *dic=@{@"key1":@"是的"};
    NSLog(@"%@\n%@",array,dic);
    
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"标题" message:@"这个是UIAlertController的默认样式" preferredStyle:UIAlertControllerStyleAlert];
////    [self presentViewController:alertController animated:YES completion:nil];
//    UIAlertAction *resetAction = [UIAlertAction actionWithTitle:@"重置" style:UIAlertActionStyleDestructive handler:nil];
//    [alertController addAction:resetAction];
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)alterView:(id)sender{
    /*
     
     类方法快速创建一个提示控制器 值得注意的是这个控制器有个preferreStyle属性你可以根据这个属性来确定是使用UIAlertView 还是 UIActionSheet
     
     UIAlertControllerStyleActionSheet
     
     UIAlertControllerStyleAlert
     
     */
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"显示的标题" message:@"标题的提示信息" preferredStyle:UIAlertControllerStyleAlert];
    
    /*
     
     UIAlertActionStyleDefault = 0,最上面的按钮
     UIAlertActionStyleCancel,最下面的取消按钮
     UIAlertActionStyleDestructive 红色警告按钮
     
     */
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"点击取消");
        
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"点击确认");
        
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"警告" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"点击警告");
        
    }]];
    
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        
        NSLog(@"添加一个textField就会调用 这个block");
        
    }];
    
    // 由于它是一个控制器 直接modal出来就好了
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)actionSheet:(id)sender{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"保存或删除数据" message:@"删除数据将不可恢复" preferredStyle: UIAlertControllerStyleActionSheet];
    /*
     
     UIAlertActionStyleDefault = 0,最上面的按钮
     UIAlertActionStyleCancel,最下面的取消按钮
     UIAlertActionStyleDestructive 红色警告按钮
     
     */
    [alertController addAction:[UIAlertAction actionWithTitle:@"保存" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"保存");
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        NSLog(@"取消");
        
    }]];
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"删除");
    }]];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
